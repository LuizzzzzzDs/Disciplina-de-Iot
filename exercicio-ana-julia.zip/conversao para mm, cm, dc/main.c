/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>


int main()
{
    float metros;

    printf("Digite o seu tamanho em metros: ");
    scanf("%f", &metros);
    float resulcm = (metros*100);
    float resuldc = (metros*10);
    float resulmm = (metros*1000);
    
    printf("Centimetros: %.2f\n", resulcm);
    printf("Milimetro: %.2f\n", resulmm);
    printf("Decimetros: %.2f\n", resuldc);
    

    return 0;
}
