/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int n1, resto;
    
    printf("Digite o seu número: ");
    scanf("%d", &n1);
    
    resto = (n1 % 3 );
    if (resto == 0){
        n1 += 1;
        printf("Seu número é divisive por 3 e agora é: %d", n1);
    }
    else {
        printf("Seu número não é divisivel por 3 ");
    }
    return 0;
}