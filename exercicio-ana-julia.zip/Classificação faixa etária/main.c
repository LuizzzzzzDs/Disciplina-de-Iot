/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int idade;
    printf("Digite a sua idade: ");
    scanf("%d", &idade);
    
    if (idade >0 && idade <18){
        printf("Você é menor de idade!");
    
        
    }else if (idade >=18 && idade <65){
        printf("Você é adulto!");
    
    
    }else if (idade >=65 && idade <120){
        printf("Você é idoso!");
    
    
    }else {
    printf("Não é possivel calcular sua idade!");
        
    }
    
    return 0;
}
