/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    float salario;
    
    printf("Digite o seu salário aqui: ");
    scanf("%f", &salario);
    
    if (salario > 0 && salario <=600){
        printf("Seu salário nao sofre alteraçoes!");
    }
    
    float result1 = salario - (salario * 0.20);
    float result2 = salario - (salario * 0.25);
    float result3 = salario - (salario * 0.30);
    
    if (salario >600 && salario <1200){
        printf("O seu salário agora é: %f", result1);
    }
    if (salario >1200 && salario <2000){
        printf("O seu salário agora é: %f", result2);
    }
    if (salario >2000 ){
        printf("O seu salário agora é: %f", result3);
    }
    
    
    return 0;
}
